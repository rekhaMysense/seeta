<?php namespace te\app\mdl;
class git_main_model {
	

	public function __construct() {
		
	}

	
	
}